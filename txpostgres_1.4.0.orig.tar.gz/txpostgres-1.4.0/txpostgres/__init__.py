__version__ = (1, 4, 0)
__versionstr__ = '.'.join([str(n) for n in __version__])
